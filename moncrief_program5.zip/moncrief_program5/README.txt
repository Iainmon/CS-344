Please run 
$ make
then
$ ./line_processor
