Just run
$ make clean && make compileall
to compile the programs. 

