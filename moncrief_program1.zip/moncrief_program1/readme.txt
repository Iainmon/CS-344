To compile, please run

$ make

