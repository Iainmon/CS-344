To compile, please run

$ make

To run, please run

$ ./movies_by_year