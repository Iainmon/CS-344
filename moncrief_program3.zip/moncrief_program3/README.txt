Please run 
$ make
then
$ ./smallsh